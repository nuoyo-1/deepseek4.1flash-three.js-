#!/usr/bin/env sh
cd "$(dirname "$0")"
(sleep 1; xdg-open http://127.0.0.1:8000 2>/dev/null || open http://127.0.0.1:8000 2>/dev/null || true) &
python3 -m http.server 8000 --bind 127.0.0.1
