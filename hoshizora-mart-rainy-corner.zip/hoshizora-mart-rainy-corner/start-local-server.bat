@echo off
cd /d "%~dp0"
echo 正在启动本地服务器，浏览器稍后会自动打开...
echo 地址: http://127.0.0.1:8000
start "" /min cmd /c "timeout /t 2 >nul & start http://127.0.0.1:8000"
python -m http.server 8000 --bind 127.0.0.1
pause
